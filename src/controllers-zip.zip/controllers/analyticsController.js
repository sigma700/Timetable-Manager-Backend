import {User} from "../database/model/users.js";
import {getInstitutionOverview} from "../../service/institutionAnalyticsService.js";
import {getTeacherWorkload} from "../../service/teacherAnalyticsService.js";
import {getSubjectDistribution} from "../../service/subjectAnalyticsService.js";
import {getTimetableHealth} from "../../service/timetableHealthService.js";
import {sendError, sendSucess} from "../../utils/sendError.js";

/**
 * GET /api/analytics/overview
 * Returns a high-level institution snapshot for the authenticated user's school.
 * Includes total counts for teachers, subjects, classes, and timetables.
 */
export const getInstitutionOverviewHandler = async (req, res) => {
  try {
    const user = await User.findById(req.userId).populate("school");

    if (!user || !user.school) {
      return sendError(res, "User is not associated with any school", 400);
    }

    const schoolId = user.school._id;

    const overview = await getInstitutionOverview(schoolId);

    return sendSucess(
      res,
      "Institution overview retrieved successfully",
      overview,
      200,
    );
  } catch (error) {
    console.log(error);
    sendError(res, error.message);
  }
};

/**
 * GET /api/analytics/teachers
 * Returns workload analytics for all teachers in the authenticated user's school.
 * Includes assigned periods, weekly/daily load, utilization %, subject and class counts.
 */
export const getTeacherWorkloadHandler = async (req, res) => {
  try {
    const user = await User.findById(req.userId).populate("school");

    if (!user || !user.school) {
      return sendError(res, "User is not associated with any school", 400);
    }

    const schoolId = user.school._id;

    const workload = await getTeacherWorkload(schoolId);

    return sendSucess(
      res,
      "Teacher workload analytics retrieved successfully",
      workload,
      200,
    );
  } catch (error) {
    console.log(error);
    sendError(res, error.message);
  }
};

/**
 * GET /api/analytics/subjects
 * Returns subject distribution analytics for the authenticated user's school.
 * Includes periods per subject, allocation %, class count, and daily average.
 */
export const getSubjectDistributionHandler = async (req, res) => {
  try {
    const user = await User.findById(req.userId).populate("school");

    if (!user || !user.school) {
      return sendError(res, "User is not associated with any school", 400);
    }

    const schoolId = user.school._id;

    const distribution = await getSubjectDistribution(schoolId);

    return sendSucess(
      res,
      "Subject distribution analytics retrieved successfully",
      distribution,
      200,
    );
  } catch (error) {
    console.log(error);
    sendError(res, error.message);
  }
};

/**
 * GET /api/analytics/health
 * Returns a timetable health score for the authenticated user's school.
 * Includes score, category, issue breakdown, and penalty components.
 */
export const getTimetableHealthHandler = async (req, res) => {
  try {
    const user = await User.findById(req.userId).populate("school");

    if (!user || !user.school) {
      return sendError(res, "User is not associated with any school", 400);
    }

    const schoolId = user.school._id;

    const health = await getTimetableHealth(schoolId);

    return sendSucess(
      res,
      "Timetable health score retrieved successfully",
      health,
      200,
    );
  } catch (error) {
    console.log(error);
    sendError(res, error.message);
  }
};
